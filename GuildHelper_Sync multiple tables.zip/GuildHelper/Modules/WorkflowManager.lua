-- Manages the workflow control and management of the syncing process for each table independently.
-- Handles confirmation requests and waits for responses.

GuildHelper = GuildHelper or {}
GuildHelper.WorkflowManager = GuildHelper.WorkflowManager or {}

function GuildHelper.WorkflowManager:StartSync(user, mode, N)
    -- List of tables to sync
    local tablesToSync = { "setup", "news", "guildInfo", "calendar" } --"roster", 
    local currentIndex = 1

    local function syncNextTable()
        if currentIndex > #tablesToSync then
            print("All tables synced successfully.")
            return
        end

        local tableName = tablesToSync[currentIndex]
        print("Starting sync with user:", user, "table:", tableName, "mode:", mode, "N:", N)
        GuildHelper.DataSyncHandler:QueueSync(user, tableName, function()
            currentIndex = currentIndex + 1
            syncNextTable()
        end)
    end

    syncNextTable()
end
