GuildHelper = GuildHelper or {}
GuildHelper.DataSyncHandler = GuildHelper.DataSyncHandler or {}

local CHUNK_SIZE = 150  -- Maximum size of each chunk
local SYNC_INTERVAL = 0.1  -- Interval between sending chunks (in seconds)

local syncQueue = {}
local isSyncing = false

function GuildHelper.DataSyncHandler:QueueSync(user, tableName, callback)
    table.insert(syncQueue, { user = user, tableName = tableName, callback = callback })
    self:ProcessQueue()
end

function GuildHelper.DataSyncHandler:ProcessQueue()
    if isSyncing or #syncQueue == 0 then return end

    isSyncing = true
    local task = table.remove(syncQueue, 1)
    self:SendData(task.user, task.tableName, function()
        isSyncing = false
        if task.callback then
            task.callback()
        end
        self:ProcessQueue()
    end)
end

function GuildHelper.DataSyncHandler:SendData(user, tableName, callback)
    local data = GuildHelper_SavedVariables.sharedData[tableName]
    local jsonData = GuildHelper.json:json_stringify(data)
    local totalChunks = math.ceil(#jsonData / CHUNK_SIZE)

    GuildHelper:AddLogEntry(string.format("Sending %s data to %s. Total chunks: %d", tableName, user, totalChunks))

    local function sendChunk(i)
        if i > totalChunks then
            if callback then callback() end
            return
        end

        local chunk = jsonData:sub((i - 1) * CHUNK_SIZE + 1, i * CHUNK_SIZE)
        local message = string.format("ENTRY_CHUNK;%s;%d;%d;%s", tableName, i, totalChunks, chunk)
        C_ChatInfo.SendAddonMessage("GUILDHELPER", message, "WHISPER", user)
        GuildHelper:AddLogEntry(string.format("Sent chunk %d/%d to %s: %s", i, totalChunks, user, chunk))

        C_Timer.After(SYNC_INTERVAL, function()
            sendChunk(i + 1)
        end)
    end

    sendChunk(1)
end

local receivedChunks = {}
local expectedChunks = 0

function GuildHelper.DataSyncHandler:HandleDataChunk(message, tableName)
    local index, total, chunk = message:match("ENTRY_CHUNK;" .. tableName .. ";(%d+);(%d+);(.+)")
    index = tonumber(index)
    total = tonumber(total)

    GuildHelper:AddLogEntry(string.format("Received chunk %d/%d: %s", index, total, chunk))

    if not receivedChunks[index] then
        receivedChunks[index] = chunk
    end

    if total > expectedChunks then
        expectedChunks = total
    end

    if #receivedChunks == expectedChunks then
        local jsonData = table.concat(receivedChunks)
        local data = GuildHelper.json:json_parse(jsonData)
        GuildHelper_SavedVariables.sharedData[tableName] = data
        GuildHelper:AddLogEntry(string.format("%s data synced successfully.", tableName))
        receivedChunks = {}
        expectedChunks = 0
    end
end

