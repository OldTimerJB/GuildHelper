GuildHelper = GuildHelper or {}
GuildHelper.ChatPane = GuildHelper.ChatPane or {}

function GuildHelper.ChatPane:CreateChatPane(parent)
    -- Create the chat pane frame
    local frame = CreateFrame("Frame", "GuildHelperChatPane", parent)
    frame:SetSize(860, 570)
    frame:SetPoint("TOPLEFT", parent, "TOPLEFT", 10, -10)

    -- Set the background texture to look like old paper
    local bgTexture = frame:CreateTexture(nil, "BACKGROUND")
    bgTexture:SetAllPoints(frame)
    bgTexture:SetTexture("Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Parchment-Horizontal")

    -- Create a title for the chat pane
    local title = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
    title:SetPoint("TOP", frame, "TOP", 0, -10)
    title:SetText("Guild Chat")

    -- Create a scroll frame for the chat messages
    local scrollFrame = CreateFrame("ScrollFrame", "GuildHelperChatScrollFrame", frame, "UIPanelScrollFrameTemplate")
    scrollFrame:SetSize(820, 450)
    scrollFrame:SetPoint("TOPLEFT", 10, -50)

    -- Create a content frame to hold the chat messages
    local content = CreateFrame("Frame", nil, scrollFrame)
    content:SetSize(800, 430)
    scrollFrame:SetScrollChild(content)

    -- Create a scrolling message frame for the chat messages
    local chatText = CreateFrame("ScrollingMessageFrame", nil, content)
    chatText:SetSize(780, 410)
    chatText:SetPoint("TOPLEFT", content, "TOPLEFT", 10, -10)
    chatText:SetFontObject("GameFontHighlightSmall")
    chatText:SetJustifyH("LEFT")
    chatText:SetMaxLines(1000)
    chatText:EnableMouseWheel(true)
    chatText:SetFading(false)
    chatText:SetScript("OnMouseWheel", function(self, delta)
        if delta > 0 then
            self:ScrollUp()
        else
            self:ScrollDown()
        end
    end)

    frame.chatText = chatText

    -- Create an input box for sending messages
    local inputBox = CreateFrame("EditBox", nil, frame, "InputBoxTemplate")
    inputBox:SetSize(780, 30)
    inputBox:SetPoint("BOTTOM", frame, "BOTTOM", 0, 10)
    inputBox:SetAutoFocus(false)
    inputBox:SetScript("OnEnterPressed", function(self)
        local message = self:GetText()
        if message ~= "" then
            GuildHelper.ChatPane:SendMessage(message)
            self:SetText("")
        end
    end)

    frame.inputBox = inputBox

    -- Show the frame
    frame:Show()

    GuildHelper.ChatPane.frame = frame
end

function GuildHelper.ChatPane:SendMessage(message)
    -- Get the chat channel name from the shared data
    local chatChannel = GuildHelper_SavedVariables.sharedData.setup.data.chat.chatchannel

    if chatChannel then
        -- Send the message to the chat
        local playerName = UnitName("player")
        local formattedMessage = string.format("[%s] %s: %s", date("%Y-%m-%d %H:%M:%S"), playerName, message)
        GuildHelper.ChatPane.frame.chatText:AddMessage(formattedMessage)
        -- Send the message to the private chat channel
        SendChatMessage(message, "CHANNEL", nil, GetChannelName(chatChannel))
    else
        print("Chat channel name not found. Message not sent.")
    end
end
