-- This file is for the Guild Master to setup guilds for this addon
-- This will be where Multi-Guild support will be added
-- This will be where the guilds are added and removed
-- This will be where the guilds are selected
-- This will be where the permissions are set for the roles or ranks in the guild to make edits or create news or update information

function GuildHelper:CreateSetupPane(parentFrame)
    local currentGroup = GuildHelper:isGuildFederatedMember()
    if not currentGroup or #currentGroup == 0 then
        return
    end

    local combinedGuildName = GuildHelper:GetCombinedGuildName()  -- Use the combined guild name

    if combinedGuildName == "NA" then
        return
    end

    if not GuildHelper_SavedVariables.sharedData.setup then
        GuildHelper_SavedVariables.sharedData.setup = {}
    end

    -- Find the setup data for the current guild or any federated guild
    local setupData = nil
    for _, guild in ipairs(currentGroup) do
        setupData = GuildHelper_SavedVariables.sharedData.setup[guild.name]
        if setupData then
            break
        end
    end

    if not setupData then
        setupData = {
            id = combinedGuildName,
            tableType = "setup",
            guildName = combinedGuildName,
            lastUpdated = "19990101000000",  -- Default date
            deleted = false,
            data = { guilds = {}, chat = {} }
        }
        GuildHelper_SavedVariables.sharedData.setup[combinedGuildName] = setupData
    end

    local setupFrame = GuildHelper:CreateStandardFrame(parentFrame)

    -- Set the background texture to look like old paper
    local bgTexture = setupFrame:CreateTexture(nil, "BACKGROUND")
    bgTexture:SetAllPoints(setupFrame)
    bgTexture:SetTexture("Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Parchment-Horizontal")

    -- Add a title
    local title = setupFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
    title:SetPoint("TOP", setupFrame, "TOP", 0, -10)
    title:SetText("Setup Guilds")

    -- Add a box for adding guild names
    local guildNameLabel = setupFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    guildNameLabel:SetPoint("TOPLEFT", setupFrame, "TOPLEFT", 20, -50)
    guildNameLabel:SetText("Guild Name:")

    -- Ensure guildNameEditBox is initialized
    local guildNameEditBox = CreateFrame("EditBox", nil, setupFrame, "InputBoxTemplate")
    guildNameEditBox:SetSize(200, 30)
    guildNameEditBox:SetPoint("LEFT", guildNameLabel, "RIGHT", 10, 0)
    guildNameEditBox:SetAutoFocus(false)
    guildNameEditBox:SetText(combinedGuildName)  -- Set default text to the full guild name

    local tempGuildList = setupData.data.guilds

    local addButton = CreateFrame("Button", nil, setupFrame, "GameMenuButtonTemplate")
    addButton:SetSize(100, 30)
    addButton:SetPoint("LEFT", guildNameEditBox, "RIGHT", 10, 0)
    addButton:SetText("Add")
    addButton:SetScript("OnClick", function()
        local guildName = guildNameEditBox:GetText()
        if guildName and guildName ~= "" then
            if not guildName:find("-") then
                print("Invalid guild name format. Please include the realm name (e.g., GuildName-Realm).")
            else
                local exists = false
                for _, guild in ipairs(tempGuildList) do
                    if guild.name == guildName then
                        exists = true
                        break
                    end
                end
                if not exists then
                    table.insert(tempGuildList, { name = guildName })
                    guildNameEditBox:SetText("")
                    GuildHelper:UpdateGuildList(setupFrame, tempGuildList)
                else
                    print("Guild name already exists in the list.")
                end
            end
        end
    end)

    -- Create a scroll frame for the guild list
    local scrollFrame = CreateFrame("ScrollFrame", nil, setupFrame, "UIPanelScrollFrameTemplate")
    scrollFrame:SetSize(300, 200)
    scrollFrame:SetPoint("TOPLEFT", guildNameLabel, "BOTTOMLEFT", 0, -20)

    local guildListFrame = CreateFrame("Frame", nil, scrollFrame)
    guildListFrame:SetSize(300, 200)
    scrollFrame:SetScrollChild(guildListFrame)

    setupFrame.guildListFrame = guildListFrame

    -- Add fields for Chat Channel and Channel Password
    local chatChannelLabel = setupFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    chatChannelLabel:SetPoint("TOPLEFT", guildNameLabel, "BOTTOMLEFT", 0, -250)
    chatChannelLabel:SetText("Chat Channel:")

    local chatChannelEditBox = CreateFrame("EditBox", nil, setupFrame, "InputBoxTemplate")
    chatChannelEditBox:SetSize(200, 30)
    chatChannelEditBox:SetPoint("LEFT", chatChannelLabel, "RIGHT", 10, 0)
    chatChannelEditBox:SetAutoFocus(false)
    chatChannelEditBox:SetText(setupData.data.chat.chatchannel or "")  -- Set default text to the saved chat channel

    local channelPasswordLabel = setupFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    channelPasswordLabel:SetPoint("TOPLEFT", chatChannelLabel, "BOTTOMLEFT", 0, -20)
    channelPasswordLabel:SetText("Channel Password:")

    local channelPasswordEditBox = CreateFrame("EditBox", nil, setupFrame, "InputBoxTemplate")
    channelPasswordEditBox:SetSize(200, 30)
    channelPasswordEditBox:SetPoint("LEFT", channelPasswordLabel, "RIGHT", 10, 0)
    channelPasswordEditBox:SetAutoFocus(false)
    channelPasswordEditBox:SetText(setupData.data.chat.channelpassword or "")  -- Set default text to the saved channel password

    -- Add a save button
    local saveButton = CreateFrame("Button", nil, setupFrame, "GameMenuButtonTemplate")
    saveButton:SetSize(100, 30)
    saveButton:SetPoint("BOTTOMLEFT", setupFrame, "BOTTOMLEFT", 20, 20)
    saveButton:SetText("Save")
    saveButton:SetScript("OnClick", function()
        -- Save setup information logic here
        setupData.data.guilds = tempGuildList
        setupData.data.chat.chatchannel = chatChannelEditBox:GetText()
        setupData.data.chat.channelpassword = channelPasswordEditBox:GetText()
        setupData.lastUpdated = date("%Y%m%d%H%M%S")
        GuildHelper:SaveSetupInfo(setupData)
    end)

    GuildHelper:UpdateGuildList(setupFrame, tempGuildList)

    -- Store references to the edit boxes for later use
    setupFrame.guildNameEditBox = guildNameEditBox
    setupFrame.chatChannelEditBox = chatChannelEditBox
    setupFrame.channelPasswordEditBox = channelPasswordEditBox

    -- Load setup info
    GuildHelper:LoadSetupInfo(setupFrame)
end

function GuildHelper:SaveGuildName(guildName, currentGroup)
    local realmName = GetRealmName()
    if not guildName:find("-") then
        guildName = guildName .. "-" .. realmName
    end
    table.insert(currentGroup.guilds, { name = guildName })
    currentGroup.lastUpdated = date("%Y%m%d%H%M%S")
end

function GuildHelper:UpdateGuildList(setupFrame, guilds)
    local guildListFrame = setupFrame.guildListFrame
    local children = { guildListFrame:GetChildren() }
    for i = 1, #children do
        children[i]:Hide()
    end

    for index, guild in ipairs(guilds) do
        if type(guild.name) == "string" then  -- Ensure guild.name is a string
            local row = CreateFrame("Frame", nil, guildListFrame)
            row:SetSize(300, 30)
            row:SetPoint("TOPLEFT", guildListFrame, "TOPLEFT", 0, -30 * (index - 1))

            local nameLabel = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            nameLabel:SetPoint("LEFT", row, "LEFT", 10, 0)
            nameLabel:SetText(guild.name)

            local removeButton = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
            removeButton:SetSize(20, 20)
            removeButton:SetPoint("RIGHT", row, "RIGHT", -10, 0)
            removeButton:SetText("X")
            removeButton:SetScript("OnClick", function()
                for i, g in ipairs(guilds) do
                    if g.name == guild.name then
                        table.remove(guilds, i)
                        break
                    end
                end
                GuildHelper:UpdateGuildList(setupFrame, guilds)
            end)
        else
        end
    end
end

function GuildHelper:RemoveGuildName(guildName, currentGroup)
    for i, guild in ipairs(currentGroup.guilds) do
        if guild.name == guildName then
            table.remove(currentGroup.guilds, i)
            break
        end
    end
end

function GuildHelper:SaveLinkedGuilds(currentGroup)
    local currentGuildName = GetGuildInfo("player") or "NA"
    if not GuildHelper_SavedVariables.sharedData.setup then
        GuildHelper_SavedVariables.sharedData.setup = {}
    end
    local setupData = GuildHelper_SavedVariables.sharedData.setup[currentGuildName]
    if not setupData then
        setupData = {
            id = currentGuildName,
            tableType = "setup",
            guildName = currentGuildName,
            lastUpdated = date("%Y%m%d%H%M%S"),
            deleted = false,
            data = { guilds = {}, chat = {} }
        }
        GuildHelper_SavedVariables.sharedData.setup[currentGuildName] = setupData
    end

    -- Find the group that contains the current guild
    local groupFound = false
    for i, guild in ipairs(setupData.data.guilds) do
        if guild.name == currentGuildName then
            setupData.data.guilds[i] = currentGroup
            groupFound = true
            break
        end
    end

    -- If no group is found, add the current group to setupData.data.guilds
    if not groupFound then
        table.insert(setupData.data.guilds, currentGroup)
    end

    GuildHelper:FilterGuildData()
end

function GuildHelper:FilterGuildData()
    local currentGroup = GuildHelper:isGuildFederatedMember()

    local filteredRoster = {}
    local roster = GuildHelper_SavedVariables.sharedData.roster or {}

    for toonName, toonData in pairs(roster) do
        for _, guild in ipairs(currentGroup) do
            if toonData.pt_guildName == guild.name then
                filteredRoster[toonName] = toonData
                break
            end
        end
    end

    GuildHelper_SavedVariables.filteredRoster = filteredRoster
end

-- Ensure the CreateSetupPane method is defined in the GuildHelper table
GuildHelper.CreateSetupPane = GuildHelper.CreateSetupPane

function GuildHelper:LoadSetupInfo(setupFrame)
    -- Ensure guildNameEditBox is not nil
    if not setupFrame.guildNameEditBox then
        return
    end

    -- Load setup info
    local setupInfo = GuildHelper_SavedVariables.sharedData.setup or {}
    local combinedGuildName = GuildHelper:GetCombinedGuildName()
    setupFrame.guildNameEditBox:SetText(combinedGuildName)  -- Set default text to the full guild name

    -- Find the setup data for the current guild or any federated guild
    local setupData = nil
    for _, guild in ipairs(GuildHelper:isGuildFederatedMember()) do
        setupData = setupInfo[guild.name]
        if setupData then
            break
        end
    end

    if setupData then
        GuildHelper:UpdateGuildList(setupFrame, setupData.data.guilds)
        setupFrame.chatChannelEditBox:SetText(setupData.data.chat.chatchannel or "")
        setupFrame.channelPasswordEditBox:SetText(setupData.data.chat.channelpassword or "")
    end
end

-- Define the SaveSetupInfo method
function GuildHelper:SaveSetupInfo(setupData)
    -- Ensure no nil values are passed
    setupData.guildName = setupData.guildName or "NA"
    setupData.data = setupData.data or { guilds = {}, chat = {} }
    setupData.lastUpdated = setupData.lastUpdated or date("%Y%m%d%H%M%S")

    GuildHelper_SavedVariables.sharedData.setup[setupData.id] = setupData
end
