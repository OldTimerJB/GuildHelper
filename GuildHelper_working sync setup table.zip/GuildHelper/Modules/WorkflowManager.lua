-- Manages the workflow control and management of the syncing process for each table independently.
-- Handles confirmation requests and waits for responses.

GuildHelper = GuildHelper or {}
GuildHelper.WorkflowManager = GuildHelper.WorkflowManager or {}

function GuildHelper.WorkflowManager:StartSync(user, mode, N)
    -- Implement the sync logic here
    print("Starting sync with user:", user, "mode:", mode, "N:", N)
    -- Call the DataSyncHandler to send setup data
    GuildHelper.DataSyncHandler:SendSetupData(user)
end
