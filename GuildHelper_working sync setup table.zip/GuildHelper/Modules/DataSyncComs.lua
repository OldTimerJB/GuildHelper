-- Manages data sync communications between clients.
-- Handles sending and receiving data chunks and addon messages.

GuildHelper = GuildHelper or {}
GuildHelper.DataSyncComs = GuildHelper.DataSyncComs or {}
