GuildHelper = GuildHelper or {}
GuildHelper.DataSyncManager = GuildHelper.DataSyncManager or {}
