GuildHelper = GuildHelper or {}
GuildHelper.DataSyncHandler = GuildHelper.DataSyncHandler or {}

local CHUNK_SIZE = 150  -- Maximum size of each chunk

function GuildHelper.DataSyncHandler:SendSetupData(user)
    local setupData = GuildHelper_SavedVariables.sharedData.setup
    local jsonData = GuildHelper.json:json_stringify(setupData)
    local totalChunks = math.ceil(#jsonData / CHUNK_SIZE)

    GuildHelper:AddLogEntry(string.format("Sending setup data to %s. Total chunks: %d", user, totalChunks))

    for i = 1, totalChunks do
        local chunk = jsonData:sub((i - 1) * CHUNK_SIZE + 1, i * CHUNK_SIZE)
        local message = string.format("SETUP_DATA_CHUNK;%d;%d;%s", i, totalChunks, chunk)
        C_ChatInfo.SendAddonMessage("GUILDHELPER", message, "WHISPER", user)
        GuildHelper:AddLogEntry(string.format("Sent chunk %d/%d to %s: %s", i, totalChunks, user, chunk))
    end
end

local receivedChunks = {}
local expectedChunks = 0

function GuildHelper.DataSyncHandler:HandleSetupDataChunk(message)
    local index, total, chunk = message:match("SETUP_DATA_CHUNK;(%d+);(%d+);(.+)")
    index = tonumber(index)
    total = tonumber(total)

    GuildHelper:AddLogEntry(string.format("Received chunk %d/%d: %s", index, total, chunk))

    if not receivedChunks[index] then
        receivedChunks[index] = chunk
    end

    if total > expectedChunks then
        expectedChunks = total
    end

    if #receivedChunks == expectedChunks then
        local jsonData = table.concat(receivedChunks)
        local setupData = GuildHelper.json:json_parse(jsonData)
        GuildHelper_SavedVariables.sharedData.setup = setupData
        GuildHelper:AddLogEntry("Setup data synced successfully.")
        receivedChunks = {}
        expectedChunks = 0
    end
end

