GuildHelper = GuildHelper or {}
GuildHelper.GuildChat = GuildHelper.GuildChat or {}